from django.contrib import admin
from .models import Noticia, Like

admin.site.register(Noticia)
admin.site.register(Like)
