from django.contrib import admin
from .models import TipoBodega, Bodega, Cotizacion

admin.site.register(TipoBodega)
admin.site.register(Bodega)
admin.site.register(Cotizacion)
